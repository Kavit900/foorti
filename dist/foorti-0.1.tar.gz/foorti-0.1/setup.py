import os

from setuptools import find_packages
from setuptools import setup


setup(
    name='foorti',
    version=0.1,
    author='zenwraight',
    author_email='kavitmht@gmail.com'
)